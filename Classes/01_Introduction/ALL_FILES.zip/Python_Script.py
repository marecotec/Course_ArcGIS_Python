import arcpy

arcpy.AddMessage("Hello, this is an add message output")

print("This is a print statement")
