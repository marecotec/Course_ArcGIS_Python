# 1 Introduction

This class is largely about introducing the class and how we will work during the Semester.

Please view the Powerpoint file if you want to review the materials.
