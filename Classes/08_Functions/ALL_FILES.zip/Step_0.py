# Step 0 - Warm up task

# Develop a small script that uses two datasets from RIGIS.org and undertake a geoprocessing routine on the
# data.

# This could be a spatial join, a buffer, an intersect, an extract by mask for example.
# there are no restrictions on the tool or dataset, and there is no answer file for this,
# so please do go forward with producing a simple script.
