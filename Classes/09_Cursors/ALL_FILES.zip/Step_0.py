
#####
# Step 0 - Practice tasks before we start.
#####

# Express these items as a list using list append (i.e. .append) and print it:

item1 = "woodlands.shp"
item2 = "marshlands.shp"
item3 = "beaches.shp"

# How many files are in the list?


# Take this list of files (file_list), and using a for loop, go through each file name and change
# the file extension from shp to csv and print new_extension_file_list.
# Hint: I would use something like filename.split(".") to extract the filename[0] which would be the
# part of the name without the extension.


